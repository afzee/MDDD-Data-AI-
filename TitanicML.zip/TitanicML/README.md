# Titanic Model Lab

A Streamlit dashboard for learning machine learning with `titanicdata.csv`.
Choose between a linear probability model and a decision tree, select passenger
features, and compare predictions with outcomes on a held-out test set. It opens
with the original `Survived` vs. `Sex` comparison.

## Run locally

```bash
python -m pip install -r requirements.txt
streamlit run app.py
```

The dashboard encodes male as `0` and female as `1`. It explains training and
test data, missing-value imputation, model coefficients or tree rules, and
model-specific test metrics. Numeric missing values (including Age) are imputed
using the training-set median.
