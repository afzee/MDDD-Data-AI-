import csv
from pathlib import Path

import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    mean_squared_error,
    r2_score,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.tree import DecisionTreeClassifier, export_text


DATA_PATH = Path(__file__).with_name("titanicdata.csv")
FEATURES = {
    "Sex": "Sex",
    "Passenger class": "Pclass",
    "Age": "Age",
    "Fare": "Fare",
    "Siblings / spouses": "SibSp",
    "Parents / children": "Parch",
}

st.set_page_config(
    page_title="Titanic Model Lab",
    page_icon="🚢",
    layout="wide",
)


@st.cache_data
def load_data(path: Path) -> pd.DataFrame:
    with path.open(newline="", encoding="utf-8-sig") as file:
        reader = csv.reader(file)
        headers = next(reader)
        rows = []

        for line in file:
            line = line.rstrip("\r\n")
            fields = next(csv.reader([line]))
            if len(fields) == 1:
                fields = next(csv.reader([fields[0]]))
            rows.append(fields)

    data = pd.DataFrame(rows, columns=headers)
    required_columns = {"Survived", *FEATURES.values()}
    missing_columns = required_columns.difference(data.columns)
    if missing_columns:
        raise ValueError(
            f"Dataset is missing required columns: {', '.join(sorted(missing_columns))}"
        )

    data["Survived"] = pd.to_numeric(data["Survived"], errors="coerce")
    data["Sex"] = data["Sex"].str.strip().str.lower()
    data = data.dropna(subset=["Survived", "Sex"])
    data = data[data["Sex"].isin(["female", "male"])].copy()
    data["Sex"] = data["Sex"].map({"male": 0.0, "female": 1.0})

    for column in FEATURES.values():
        if column != "Sex":
            data[column] = pd.to_numeric(data[column], errors="coerce")
    return data


st.title("Titanic Model Lab")
st.caption("Build a model, test it on unseen passengers, and learn what its results mean.")

try:
    data = load_data(DATA_PATH)
except (OSError, ValueError, csv.Error) as error:
    st.error(f"Could not load the Titanic dataset: {error}")
    st.stop()

with st.sidebar:
    st.header("Model setup")
    model_name = st.selectbox(
        "Choose a model",
        ["Linear Regression", "Decision Tree"],
        help="Both models use the same selected features and test passengers.",
    )
    selected_features = st.multiselect(
        "Features (inputs)",
        options=list(FEATURES),
        default=["Sex"],
        help="Start with Sex, then add other passenger details to compare.",
    )
    test_size = st.slider(
        "Passengers held back for testing",
        min_value=10,
        max_value=40,
        value=20,
        step=5,
        format="%d%%",
    )
    if model_name == "Decision Tree":
        max_depth = st.slider(
            "Maximum tree depth",
            min_value=1,
            max_value=5,
            value=3,
            help="A deeper tree can learn more detailed rules, but may overfit.",
        )

    st.markdown("**Target (what the model learns to predict)**")
    st.code("Survived")
    st.markdown("**Selected inputs**")
    st.write(", ".join(selected_features) if selected_features else "Choose at least one feature.")

if not selected_features:
    st.info("Select one or more features in the sidebar to train a model.")
    st.stop()

selected_columns = [FEATURES[name] for name in selected_features]
X = data[selected_columns].rename(
    columns={FEATURES[name]: name for name in selected_features}
)
y = data["Survived"].astype(int)
train_indices, test_indices = train_test_split(
    data.index,
    test_size=test_size / 100,
    random_state=42,
    stratify=y,
)
X_train, X_test = X.loc[train_indices], X.loc[test_indices]
y_train, y_test = y.loc[train_indices], y.loc[test_indices]

if model_name == "Linear Regression":
    model = make_pipeline(SimpleImputer(strategy="median"), LinearRegression())
else:
    model = make_pipeline(
        SimpleImputer(strategy="median"),
        DecisionTreeClassifier(
            max_depth=max_depth,
            min_samples_leaf=10,
            random_state=42,
        ),
    )

model.fit(X_train, y_train)
test_predictions = model.predict(X_test)
test_rows = data.loc[test_indices, ["Sex", "Survived"]].copy()
test_rows["Sex"] = test_rows["Sex"].map({0.0: "Male", 1.0: "Female"})
test_rows["Observed survival"] = y_test.to_numpy()

st.subheader("What is the model trying to learn?")
st.markdown(
    "Each row is one passenger. **Features** are the inputs (such as Sex or Age); "
    "**Survived** is the answer the model learns from. We hold some passengers "
    "back before fitting, then check whether the model predicts those unseen cases."
)

if model_name == "Linear Regression":
    rmse = float(np.sqrt(mean_squared_error(y_test, test_predictions)))
    r_squared = float(r2_score(y_test, test_predictions))
    metric_columns = st.columns(4)
    metric_columns[0].metric("Training passengers", f"{len(train_indices):,}")
    metric_columns[1].metric("Test passengers", f"{len(test_indices):,}")
    metric_columns[2].metric("Test R²", f"{r_squared:.3f}")
    metric_columns[3].metric("Test RMSE", f"{rmse:.3f}")

    st.info(
        "Because Survived is 0 or 1, this is a **linear probability model**: "
        "predictions are interpreted like survival scores, but linear regression "
        "does not constrain them to stay between 0 and 1."
    )

    regression = model.named_steps["linearregression"]
    coefficient_table = pd.DataFrame(
        {
            "Feature": selected_features,
            "Coefficient": regression.coef_,
        }
    )
    coefficient_table["Coefficient"] = coefficient_table["Coefficient"].map(
        lambda value: f"{value:+.3f}"
    )
    st.markdown("#### How to read the coefficients")
    st.write(
        "The model adds a weighted contribution from each feature to a starting "
        "value (the intercept). A positive coefficient raises the prediction; a "
        "negative one lowers it, while other selected features are held constant."
    )
    st.latex(
        r"\widehat{\text{Survived}} = "
        + f"{regression.intercept_:.3f}"
        + "".join(
            rf" {coefficient:+.3f}\times\text{{{feature}}}"
            for feature, coefficient in zip(selected_features, regression.coef_)
        )
    )
    if selected_features == ["Sex"]:
        st.caption("Sex is encoded as male = 0 and female = 1.")
    st.dataframe(coefficient_table, hide_index=True, width="stretch")
    st.markdown("#### Visualize the fitted regression line")
    plot_feature = st.selectbox(
        "Feature to show on the x-axis",
        options=selected_features,
        format_func=lambda feature: f"{feature} (male = 0, female = 1)"
        if feature == "Sex"
        else feature,
        help=(
            "The line shows the model's prediction as this feature changes, "
            "while other selected features stay at their training-set medians."
        ),
    )

    if plot_feature == "Sex":
        x_values = np.array([0.0, 1.0])
    else:
        feature_values = X_train[plot_feature].dropna()
        x_min, x_max = feature_values.quantile([0.05, 0.95])
        if x_min == x_max:
            x_min, x_max = float(feature_values.min()), float(feature_values.max())
        x_values = np.linspace(x_min, x_max, 100)

    prediction_inputs = pd.DataFrame(
        {
            feature: np.repeat(X_train[feature].median(), len(x_values))
            for feature in selected_features
        }
    )
    prediction_inputs[plot_feature] = x_values
    line_predictions = model.predict(prediction_inputs)

    figure, axis = plt.subplots(figsize=(8, 4))
    actual_x = X_train[plot_feature].to_numpy(dtype=float)
    actual_y = y_train.to_numpy(dtype=float)
    rng = np.random.default_rng(42)
    if plot_feature == "Sex":
        actual_x = actual_x + rng.uniform(-0.06, 0.06, len(actual_x))
    actual_y = actual_y + rng.uniform(-0.025, 0.025, len(actual_y))
    axis.scatter(
        actual_x,
        actual_y,
        alpha=0.22,
        s=18,
        color="#3b82f6",
        label="Training passengers (observed)",
    )
    axis.plot(
        x_values,
        line_predictions,
        color="#dc2626",
        linewidth=2.5,
        marker="o" if plot_feature == "Sex" else None,
        label="Linear regression prediction",
    )
    axis.axhline(0, color="#64748b", linestyle=":", linewidth=1)
    axis.axhline(1, color="#64748b", linestyle=":", linewidth=1)
    axis.set_xlabel(
        f"{plot_feature} (male = 0, female = 1)"
        if plot_feature == "Sex"
        else plot_feature
    )
    axis.set_ylabel("Survived (0 = no, 1 = yes)")
    axis.set_title("Observed training outcomes and model prediction")
    axis.legend(loc="best")
    axis.grid(alpha=0.2)
    if plot_feature == "Sex":
        axis.set_xticks([0, 1], ["Male", "Female"])
    st.pyplot(figure, width="stretch")
    plt.close(figure)
    st.caption(
        "Blue dots are individual training passengers (slight jitter separates "
        "overlapping 0/1 outcomes). The red line is the model prediction; with "
        "multiple features, all other inputs are held at their training-set "
        "medians. For numeric features the plot focuses on the 5th–95th percentile "
        "range. Dotted lines mark the possible survival outcomes. Values of the "
        "red line outside 0–1 illustrate that linear regression is not bounded "
        "like a probability model."
    )
    st.caption(
        "RMSE is the typical prediction error on the 0–1 target scale; lower is "
        "better. R² compares the model with an average-only prediction on this "
        "test set; closer to 1 is better, while a negative score is worse than "
        "that simple baseline."
    )
else:
    accuracy = float(accuracy_score(y_test, test_predictions))
    majority_baseline = float(y_train.value_counts(normalize=True).max())
    tree = model.named_steps["decisiontreeclassifier"]
    survival_class_index = list(tree.classes_).index(1)
    test_score_predictions = model.predict_proba(X_test)[:, survival_class_index]
    metric_columns = st.columns(4)
    metric_columns[0].metric("Training passengers", f"{len(train_indices):,}")
    metric_columns[1].metric("Test passengers", f"{len(test_indices):,}")
    metric_columns[2].metric("Test accuracy", f"{accuracy:.1%}")
    metric_columns[3].metric("Majority-class baseline", f"{majority_baseline:.1%}")

    st.info(
        "A decision tree learns a sequence of **if/then questions**. Each split "
        "sends passengers down a branch; the final leaf predicts the most common "
        "outcome among similar training passengers."
    )
    rules = export_text(
        tree,
        feature_names=selected_features,
        class_names=["Did not survive", "Survived"],
        max_depth=max_depth,
        show_weights=True,
    )
    st.markdown("#### The tree's learned rules")
    st.code(rules, language="text")
    st.caption(
        "Each leaf's class counts come from training passengers only. "
        "Maximum depth limits the number of question levels; a very deep tree "
        "can memorize training examples and perform poorly on new passengers."
    )

    importance = pd.Series(
        tree.feature_importances_,
        index=selected_features,
        name="Importance",
    ).sort_values(ascending=False)
    st.markdown("#### Which features did the tree use?")
    if importance.max() == 0:
        st.write("The tree did not use any feature to make a split.")
    else:
        st.bar_chart(importance, y_label="Relative importance")
    st.caption(
        "Importance summarizes how much a feature helped reduce mixed outcomes "
        "across the tree's splits. It is not a causal effect."
    )

    matrix = confusion_matrix(y_test, test_predictions, labels=[0, 1])
    matrix_frame = pd.DataFrame(
        matrix,
        index=["Actual: did not survive", "Actual: survived"],
        columns=["Predicted: did not survive", "Predicted: survived"],
    )
    st.markdown("#### Test-set confusion matrix")
    st.dataframe(matrix_frame, width="stretch")
    st.caption(
        "The diagonal cells are correct predictions. Off-diagonal cells show "
        "which kind of mistake the model made."
    )

st.subheader("How did it do on unseen passengers?")
if model_name == "Linear Regression":
    test_score_predictions = test_predictions
test_rows["Model prediction"] = test_score_predictions
test_rates = (
    test_rows.groupby("Sex", observed=True)
    .agg(
        actual=("Observed survival", "mean"),
        predicted=("Model prediction", "mean"),
        passengers=("Observed survival", "size"),
    )
    .reindex(["Male", "Female"])
)
chart_rates = test_rates[["actual", "predicted"]].mul(100)
chart_rates.columns = ["Observed survival", "Average model prediction"]
left, right = st.columns([1.5, 1])
with left:
    st.bar_chart(
        chart_rates,
        y=["Observed survival", "Average model prediction"],
        x_label="Sex of test passengers",
        y_label="Model estimate / survival rate (%)",
    )
with right:
    st.markdown("#### Test passengers by sex")
    display_rates = test_rates[["passengers", "actual"]].copy()
    display_rates["actual"] = display_rates["actual"].map(
        lambda value: f"{value:.1%}"
    )
    display_rates.columns = ["Passengers", "Observed survival"]
    st.dataframe(display_rates, width="stretch")
    if model_name == "Linear Regression":
        st.caption(
            "Linear regression scores can fall below 0% or above 100%; the chart "
            "shows the raw average score rather than clipping it."
        )
    else:
        st.caption(
            "The tree's estimates are the fraction of surviving training "
            "passengers in each predicted leaf."
        )

with st.expander("Train set vs. test set: why split the data?"):
    st.write(
        "The model learns its coefficients or rules from the training passengers. "
        "The test passengers are kept separate until evaluation, giving a more "
        "honest check of how well the model may work on unfamiliar examples. "
        "This dashboard uses a fixed random seed and stratifies the split so both "
        "sets have a similar share of survivors. Missing numeric inputs such as "
        "Age are filled with the training-set median by a preprocessing step "
        "inside the model pipeline."
    )

with st.expander("Compare the two model ideas"):
    st.markdown(
        "- **Linear regression** fits a weighted straight-line formula. Its "
        "coefficients show the direction and size of each feature's contribution, "
        "but interactions and curved patterns are not automatic.\n"
        "- **Decision tree** builds readable threshold rules and can capture "
        "non-linear patterns. It is easy to overfit, so limiting depth and checking "
        "held-out passengers matter.\n"
        "- Neither model proves that a feature caused survival. They describe "
        "patterns in this historical dataset."
    )

with st.expander("Preview dataset"):
    st.dataframe(data, width="stretch")
